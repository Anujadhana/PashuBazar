import React from "react";
import "./Loader.css";
const Loader = () => {
  return (
    // <div class="main-circle rotate">
    //   <div class="second-circle rotate">
    //     <div class="circle big" id="circle-1"></div>
    //     <div class="two-circle">
    //       <div class="circle big" id="circle-2"></div>
    //       <div style={{ padding: "15px" }}></div>
    //       <div class="circle big" id="circle-3"></div>
    //     </div>
    //   </div>
    // </div>
    <div class="container">
      <div class="loader"></div>
    </div>
  );
};

export default Loader;
